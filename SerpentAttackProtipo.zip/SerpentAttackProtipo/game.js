// --- 1. CONFIGURACIÓN INICIAL ---

// Elementos de las pantallas
const menuScreen = document.getElementById('menu-screen');
const gameScreen = document.getElementById('game-screen');
const helpScreen = document.getElementById('help-screen');
const exitScreen = document.getElementById('exit-screen');

// Elementos Modales
const modalOverlay = document.getElementById('modal-overlay');
const gameOverModal = document.getElementById('game-over-modal');
const levelUpModal = document.getElementById('level-up-modal');
const restartButton = document.getElementById('restart-button');
const nextLevelButton = document.getElementById('next-level-button');

// Botones
const startButton = document.getElementById('start-button');
const helpButton = document.getElementById('help-button');
const backButton = document.getElementById('back-button');
const exitButton = document.getElementById('exit-button');

// Elementos de Texto
const challengeDescription = document.getElementById('challenge-description');
const highScoreDisplay = document.getElementById('high-score-display');
const scoreDisplay = document.getElementById('score-display');
const timerDisplay = document.getElementById('timer-display');
const levelDisplay = document.getElementById('level-display');

// Elementos del Canvas
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Configuración del juego
const tileSize = 20;
const gridWidth = canvas.width / tileSize;
const gridHeight = canvas.height / tileSize;
const labyrinth = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1],
    [1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1],
    [1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1],
    [1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
];
const snakeImage = new Image();
const mouseImage = new Image();
const wallImage = new Image();
snakeImage.src = 'snake.png';
mouseImage.src = 'mouse.png';
wallImage.src = 'wall.png';

// Variables del juego
let score = 0;
let snake = { x: 1, y: 1 };
let mouse = { x: 18, y: 18 };
let currentLevel = 1;
let scoreToWin = 5;
let highScore = 0;
const startingTime = 20;
const timeAddedPerMouse = 5;
const bonusTimePerLevel = 10;
let timerInterval;
let timeLeft = 0;

// ¡NUEVO! Array para las partículas de la explosión
let particles = [];

// --- 2. LÓGICA DEL MENÚ Y ESTADOS DEL JUEGO ---

startButton.addEventListener('click', startGame);
helpButton.addEventListener('click', showHelp);
backButton.addEventListener('click', hideHelp);
exitButton.addEventListener('click', exitGame);

restartButton.addEventListener('click', () => {
    modalOverlay.classList.add('hidden');
    gameOverModal.classList.add('hidden');
    gameScreen.classList.add('hidden');
    menuScreen.classList.remove('hidden');
    updateChallengeText();
});

nextLevelButton.addEventListener('click', () => {
    modalOverlay.classList.add('hidden');
    levelUpModal.classList.add('hidden');
    
    currentLevel++;
    score = 0;
    scoreToWin += 2;
    timeLeft += bonusTimePerLevel;
    
    levelDisplay.innerText = `Nivel: ${currentLevel}`;
    scoreDisplay.innerText = `Puntos: ${score}`;
    timerDisplay.innerText = `Tiempo: ${timeLeft}`;
    
    moveMouse();
    // Reanuda el temporizador
    timerInterval = setInterval(updateTimer, 1000);
});

function startGame() {
    menuScreen.classList.add('hidden');
    gameScreen.classList.remove('hidden');
    resetGame();
    
    timeLeft = startingTime;
    timerDisplay.innerText = `Tiempo: ${timeLeft}`;
    timerInterval = setInterval(updateTimer, 1000);
}

function showHelp() {
    menuScreen.classList.add('hidden');
    helpScreen.classList.remove('hidden');
}

function hideHelp() {
    helpScreen.classList.add('hidden');
    menuScreen.classList.remove('hidden');
}

function exitGame() {
    menuScreen.classList.add('hidden');
    gameScreen.classList.add('hidden');
    helpScreen.classList.add('hidden');
    exitScreen.classList.remove('hidden');
    if (timerInterval) {
        clearInterval(timerInterval);
    }
}

function updateTimer() {
    timeLeft--;
    timerDisplay.innerText = `Tiempo: ${timeLeft}`;
    if (timeLeft <= 0) {
        endGame("¡Se acabó el tiempo!");
    }
}

function endGame(message) {
    clearInterval(timerInterval);
    const isNewRecord = saveHighScore();
    
    document.getElementById('end-game-message').innerText = message;
    document.getElementById('end-game-stats').innerText = `Alcanzaste el Nivel ${currentLevel}.`;
    if (isNewRecord) {
        document.getElementById('new-record-message').classList.remove('hidden');
    } else {
        document.getElementById('new-record-message').classList.add('hidden');
    }
    
    modalOverlay.classList.remove('hidden');
    gameOverModal.classList.remove('hidden');
}

function levelUp() {
    clearInterval(timerInterval);
    
    document.getElementById('level-up-title').innerText = `¡Nivel ${currentLevel} Superado!`;
    document.getElementById('level-up-bonus').innerText = `¡Recibes +${bonusTimePerLevel} segundos de bono!`;
    document.getElementById('level-up-next').innerText = `Prepárate para el Nivel ${currentLevel + 1}...`;
    
    modalOverlay.classList.remove('hidden');
    levelUpModal.classList.remove('hidden');
}

// --- 3. SISTEMA DE PARTÍCULAS (EFECTO ÉPICO) ---

// Función para crear una explosión en una coordenada (x, y)
function createExplosion(x, y) {
    // Creamos 20 partículas
    for (let i = 0; i < 20; i++) {
        particles.push({
            // Posición inicial: centro del cuadrado
            x: x * tileSize + tileSize / 2,
            y: y * tileSize + tileSize / 2,
            // Velocidad aleatoria (explosión)
            vx: (Math.random() - 0.5) * 8, 
            vy: (Math.random() - 0.5) * 8,
            // Color aleatorio (amarillos, naranjas y blancos)
            color: `hsl(${Math.random() * 60 + 30}, 100%, 50%)`,
            // Vida de la partícula
            life: 1.0
        });
    }
}

// Función para actualizar y dibujar partículas
function updateAndDrawParticles() {
    for (let i = 0; i < particles.length; i++) {
        let p = particles[i];
        
        // Mover partícula
        p.x += p.vx;
        p.y += p.vy;
        // Desvanecer
        p.life -= 0.04;
        
        // Dibujar
        ctx.globalAlpha = p.life; // Transparencia según vida
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 3, 0, Math.PI * 2); // Dibuja un círculo pequeño
        ctx.fill();
        ctx.globalAlpha = 1.0; // Restaurar transparencia
        
        // Eliminar partículas muertas
        if (p.life <= 0) {
            particles.splice(i, 1);
            i--;
        }
    }
}

// --- 4. LÓGICA DEL JUEGO (MOVIMIENTO Y COLISIÓN) ---

document.addEventListener('keydown', (e) => {
    if (!gameScreen.classList.contains('hidden') && modalOverlay.classList.contains('hidden')) {
        let nextX = snake.x;
        let nextY = snake.y;
        switch (e.key) {
            case 'ArrowUp': nextY--; break;
            case 'ArrowDown': nextY++; break;
            case 'ArrowLeft': nextX--; break;
            case 'ArrowRight': nextX++; break;
            default: return;
        }
        if (labyrinth[nextY][nextX] === 1) {
            endGame("¡Perdiste! Chocaste contra el muro.");
            return;
        }
        
        snake.x = nextX;
        snake.y = nextY;
        
        // Colisión con el ratón
        if (snake.x === mouse.x && snake.y === mouse.y) {
            score++;
            timeLeft += timeAddedPerMouse;
            timerDisplay.innerText = `Tiempo: ${timeLeft}`;
            
            // ¡NUEVO! Crea la explosión donde estaba el ratón
            createExplosion(mouse.x, mouse.y);

            if (score >= scoreToWin) {
                levelUp();
                return;
            } else {
                scoreDisplay.innerText = `Puntos: ${score}`;
                moveMouse();
            }
        }
        // Nota: Ya no llamamos a draw() aquí, lo hace el bucle de animación
    }
});

// --- 5. FUNCIONES DE DIBUJO Y AYUDA ---

function draw() {
    // Limpiar
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Dibujar juego
    drawLabyrinth();
    ctx.drawImage(snakeImage, snake.x * tileSize, snake.y * tileSize, tileSize, tileSize);
    ctx.drawImage(mouseImage, mouse.x * tileSize, mouse.y * tileSize, tileSize, tileSize);
    
    // ¡NUEVO! Dibujar partículas encima de todo
    updateAndDrawParticles();
}

function drawLabyrinth() {
    for (let y = 0; y < gridHeight; y++) {
        for (let x = 0; x < gridWidth; x++) {
            if (labyrinth[y][x] === 1) {
                ctx.drawImage(wallImage, x * tileSize, y * tileSize, tileSize, tileSize);
            }
        }
    }
}

function resetGame() {
    score = 0;
    currentLevel = 1;
    scoreToWin = 5;
    particles = []; // Limpiar partículas
    
    scoreDisplay.innerText = `Puntos: ${score}`;
    levelDisplay.innerText = `Nivel: ${currentLevel}`;
    snake = { x: 1, y: 1 };
    
    if (timerInterval) {
        clearInterval(timerInterval);
    }
    
    moveMouse();
}

function moveMouse() {
    let newX, newY;
    do {
        newX = Math.floor(Math.random() * gridWidth);
        newY = Math.floor(Math.random() * gridHeight);
    } while (labyrinth[newY][newX] === 1 || (newX === snake.x && newY === snake.y));
    
    mouse.x = newX;
    mouse.y = newY;
}

function updateChallengeText() {
    challengeDescription.innerText = `Nivel 1: ¡Atrapa 5 ratones antes de que el tiempo llegue a 0!`;
}

// --- 6. MÓDULO DE PERSISTENCIA ---
function loadHighScore() {
    const savedScore = localStorage.getItem('serpentAttackHighScore');
    if (savedScore) {
        highScore = parseInt(savedScore);
    }
    highScoreDisplay.innerText = `Tu Récord: Nivel ${highScore}`;
}
function saveHighScore() {
    if (currentLevel > highScore) {
        highScore = currentLevel;
        localStorage.setItem('serpentAttackHighScore', highScore);
        highScoreDisplay.innerText = `Tu Récord: Nivel ${highScore}`;
        return true;
    }
    return false;
}

// --- 7. BUCLE DE ANIMACIÓN (NUEVO) ---
// Necesitamos esto para que las partículas se muevan suavemente
function gameLoop() {
    if (!gameScreen.classList.contains('hidden')) {
        draw();
    }
    requestAnimationFrame(gameLoop);
}

// --- 8. INICIAR EL JUEGO ---
let imagesLoaded = 0;
function onImageLoad() {
    imagesLoaded++;
    if (imagesLoaded === 3) {
        startButton.disabled = false;
        helpButton.disabled = false;
        exitButton.disabled = false;
        startButton.innerText = "Empezar a Jugar";
        updateChallengeText();
        
        loadHighScore();
        
        // ¡NUEVO! Iniciamos el bucle de animación
        requestAnimationFrame(gameLoop);
    }
}

snakeImage.onload = onImageLoad;
mouseImage.onload = onImageLoad;
wallImage.onload = onImageLoad;